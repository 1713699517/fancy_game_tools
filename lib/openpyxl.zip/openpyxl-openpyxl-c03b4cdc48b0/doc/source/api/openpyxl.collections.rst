openpyxl.collections package
============================

Module contents
---------------

.. automodule:: openpyxl.collections
    :members:
    :undoc-members:
    :show-inheritance:
