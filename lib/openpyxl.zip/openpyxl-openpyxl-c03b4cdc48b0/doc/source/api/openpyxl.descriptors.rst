openpyxl.descriptors package
============================

Module contents
---------------

.. automodule:: openpyxl.descriptors
    :members:
    :undoc-members:
    :show-inheritance:
