Roadmap for future versions
===========================

[ ] Bugfix # 88 Using hyperlinks causes charts to break

[ ] Bugfix # 95 add row height and col width functionality

[ ] Bugfix # 97 adds pie charts and combination charts

[ ] Bugfix # 99 adds ticks around multi-word titles in chart references

[ ] Bugfix # 103

[ ] Bugfix # 152

[ ] Bugfix # 163

[ ] Bugfix # 172

[ ] Bugfix # 181

[ ] Bugfix # 184 support for right-to-left

[ ] Bugfix # 215 roundtrip sheetviews

[ ] Cleanup API of IterableWorksheet

[ ] Improve handling of relationships

[ ] Support cells with formulae in charts

[ ] Merge existing patches for charts

[ ] Default to using an iterator when working with charts?
