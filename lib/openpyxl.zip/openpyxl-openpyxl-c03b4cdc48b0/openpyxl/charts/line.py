from __future__ import absolute_import
# Copyright (c) 2010-2014 openpyxl

from .graph import GraphChart


class LineChart(GraphChart):

    TYPE = "lineChart"
