Collection of throwaway scripts and files used during development.
