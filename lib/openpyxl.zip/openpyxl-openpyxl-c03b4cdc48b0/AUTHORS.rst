This project is developed by Eric Gazoni.

It is *heavily* inspired by the PHPExcel library that can be
found here: http://www.phpexcel.net/

Kudos goes to the PHPExcel team, I'm only standing on their shoulders.

I'd also like to greatly thank all those who participate in the project (in alphabetical order):

* Stephane Bard
* Day Barr
* Stefan Behnel
* Bernt R. Brenna
* Sven Burk
* Anders Chrigstrom
* ccoacley
* Charlie Clark
* Maarten De Paepe
* Etienne Desautels
* Eric Chlebek
* Alexandre Fayolle
* Eric Gazoni
* Brice Gelineau
* Alex Gronholm
* Yaroslav Halchenko
* Jeff Holman
* Brent Hoover
* Eric Hurkman
* JarekPS
* Heikki Junes
* Chi Ho Kwok
* Yingjie Lan
* Detlef Lannert
* Nicholas Laver
* Greg Lehmann
* Adam Lofts
* Marko Loparic
* Samuel Loretan
* Amin Mirzaee
* Adam Morris
* aceMueller
* Gabi Nagy
* Jun Omae
* Waldemar Osuch
* Jonathan Peirce
* Sergey Pikhovkin
* Ted Pollari
* Elias Rabel
* Rick Rankin
* ramn_se
* Philip Roche
* James Smagala
* Joseph Tate
* Dieter Vandenbussche
* Paul Van Der Linden
* Gerald Van Huffelen
* Laurent Vasseur
* Kay Webber
* Shibukawa Yoshiki

Project logo designed by Eric Gazoni, font by claudeserieux
(http://www.dafont.com/profile.php?user=337503)
